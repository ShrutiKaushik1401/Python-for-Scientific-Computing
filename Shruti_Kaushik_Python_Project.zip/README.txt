1. Used Anaconda Navigator 1.8.7, Jupyter Notebook 5.5.0 on Python 3.6 version on Windows 10 enterprise, 64 bit.
2. Used Numpy, Scipy, Matplotlib, Pandas
3. Save the Dataset file for project 1 - 'Diabetes_Control_Pill_Sales_Dataset.txt'
4. Run the 'Shruti_Kaushik_Resampling_Interpolation_Extrapolation_Python_Project.py'
5. Save the Dataset file for Project 2 - 'Sales Dataset.txt'
6. Run the 'Shruti_Kaushik_Stores_Sales_Data_Analysis_Python_Project.py'